Ramas DESCARTADAS por decisión del dueño (limpieza-masiva-v1, 2026-11-28).
El trabajo (~406 líneas: QA ux-masiva-fixes, tests porcentaje-proceso,
fixes UX en MasivaView/TopBar/ReviewView/archivos) NO fue mergeado a main.
Para recuperarlo: git apply <patch> desde el commit base correspondiente.
